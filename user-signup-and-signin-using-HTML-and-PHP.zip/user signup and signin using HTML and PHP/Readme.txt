How to run the User Signup and Sign in using HTML and PHP

1.Download the zip file

2.Extract the file and copy signup-signin folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4.Open PHPMyAdmin (http://localhost/phpmyadmin)

5.Create a database with name regdb

6.Import regdb.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/signup-signin



User Credential
Username: test1@gmail.com / 6546546545
Password: 123
or Register a new user

